# CLAUDE.md

**pinchs.be** — portfolio for a software developer. Static React site, no
backend. The visitor controls a character in a 3D world; each project is a
landmark they walk up to. Trilingual EN / FR / NL.

Reference for the concept: https://messenger.abeto.co/

Full plan, phase gates and open questions: `docs/BUILD-PLAN.md`. Read it before
starting work.

## Commands

```
npm run dev        # react-router dev
npm run typecheck  # react-router typegen && tsc -b
npm run check      # the assert-based checks
npm run build      # typecheck, prerender every route, copy the root 404.html
npm run preview    # serve build/client/
```

Build output is `build/client/` — one directory of static files, which is the
whole deploy. `dist/` is gone.

**Claude must never run `npm install`, `npm ci` or `npm run build` here.**
`node_modules` contains native bindings for the host (macOS arm64), and Claude's
shell is a Linux VM sharing the same folder. Installing from it empties every
platform binding directory and cannot delete them afterwards, which breaks the
build for everyone. Recovery is `rm -rf node_modules package-lock.json && npm
install`, run by Seb on macOS.

Claude verifies with `npx tsc -b` and `node src/i18n/locales.check.ts` — pure
JS, safe from either side. `react-router typegen` and `oxlint` are *not* safe:
both ship native bindings built for macOS arm64, so they fail outright from
Claude's Linux VM and `tsc` runs against whatever types typegen last wrote.
Anything that needs a real install, a real build, typegen or the linter, Claude
does on a throwaway copy in its own cloud container, never in this folder.
Bundling and deploying are Seb's.

## Stack

Vite 8 · React 19 + TypeScript · React Router 8, framework mode, `ssr: false`
with `prerender` · `three` (WebGPURenderer + TSL) · `@react-three/fiber` ·
`@react-three/drei`. Content as MDX (`@mdx-js/rollup` + `remark-frontmatter`),
locale in the route. Deploy: static build → rsync → nginx on Seb's own Ubuntu
box at 167.233.245.42. No Node and no runtime on the server; `/var/www/pinchs.be`
is exactly `build/client/`. Root redirect and 404 live in `deploy/nginx.conf`,
not in a `_redirects` file.

The plan says "React Router 7"; v8 is what shipped. Same `react-router.config.ts`,
same `routes.ts`, same `root.tsx`, and v7 would have meant starting a new project
one major behind. Noted here rather than done quietly.

## Projects

| Slug | Landmark | Links |
|---|---|---|
| `polarsense` | A mine | https://github.com/Shambels/polarSense |
| `arts-by-sandra` | An easel and canvas | https://artsbysandra.be/ |
| `scrubble` | A Scrabble board | — |

Where each one sits in the world — `pos`, `size`, `radius`, `waypoint`, `order`
— is English frontmatter, not a table anywhere in code.

## Invariants

Breaking one is allowed. Doing it without saying so is not.

1. **No backend, no database.** A feature needing a server gets proposed, not
   built.
2. **All prose lives in the DOM.** Never render case-study text into the canvas
   — unselectable, unsearchable, invisible to screen readers.
3. **The `<Canvas>` mounts once** in the root layout and never unmounts on
   navigation. Proximity pushes a URL; it does not remount a tree.
4. **The site works fully with WebGL unavailable and with JS off.** The world is
   an enhancement over a complete site.
5. **Every landmark is reachable without walking to it** — skip link first in tab
   order, full keyboard path, direct URL.
6. **`prefers-reduced-motion` is honoured everywhere** — no idle motion, no
   camera sway, instant transitions.
7. **Content is data.** A new project is a new MDX file plus a model. Never new
   scene components.
8. **All input goes through `useInput()`.** The one permitted early abstraction,
   and it paid: Phase 6's touch controls are a thumb stick written into the same
   `move` vector, and the flight controller, the spray and the sound did not
   change a line for them.

## Conventions

- Ponytail: fewest files, shortest working diff, platform and stdlib before
  dependencies. No abstraction before its third use — except invariant 8.
- New dependency needs a one-line justification and its gzipped cost.
- No physics engine until the world needs slopes or stacking. The character
  hovers: XZ translation, sine bob, bank on turn, circle-vs-circle landmark
  collision. The boat is the same controller with its altitude pinned to the
  swell (`swell()` in `Scenery.tsx`, the CPU twin of the water's own waves) and
  a circle-vs-circle push out of each island's shoreline — still no engine. No ground following over flat terrain.
- The character stays procedural — both hulls, and the surfer's board with its
  pad, fin and wake. The **rider** is the one exception, and `tools/surfer.py`
  is where it says why: a hull is a solid of revolution with things bolted to
  it and code is good at those; a person is one skin over a skeleton. Anything
  else that wants a model file still has to argue for one first.
- No i18n library. Typed string objects per locale in `src/i18n/`.
- Canvas and models load via dynamic `import()`, never in the first-route chunk.
- TypeScript strict, no `any`. A narrow cast at a library boundary is fine — see
  `extend(THREE as never)` in `src/App.tsx`.
- No test framework. Non-trivial logic leaves one assert-based check behind.
- Models are Blender, generated by a script in `tools/` and opened to sculpt.
  Geometry only: materials stay in TSL, and a mesh's name prefix picks which one
  it gets. `tools/surfer.py` is the exception and the only one — a wetsuit with
  neon ribbons is not a material a prefix can name, so the rider carries its own
  colour in COLOR_0. He is also the only thing in the world that is not lit like
  the world: toon shading, an inverted-hull outline and a fresnel rim, because
  the sun is ahead of the ship and the visitor only ever sees his shadow side. `pip install
  "bpy==4.5.13"` (Python 3.11) and `python3 tools/<name>.py` rebuilds;
  `--render out.png` writes the preview views.
- Shaders derive from what a project does. Generic noise does not ship.

## Budgets

| Metric | Limit |
|---|---|
| First-route JS | ≤ 200 kB gz, excluding canvas chunk |
| Canvas chunk | ≤ 600 kB gz |
| Per landmark model | ≤ 300 kB compressed, ≤ 25k triangles |
| Whole world, compressed | ≤ 3 MB, loaded progressively |
| LCP (4G) | < 2.0s |
| Lighthouse, flat site | 100 / 100 / 100 / 100 |
| Frame rate | 60fps on a 2022 mid-tier laptop, or cut the effect |

## Layout

```
src/root.tsx            the HTML document — <html lang>, stylesheet, Scripts
src/routes.ts           the route table
src/routes/locale.tsx   :lang layout — validates the locale, chrome, hreflang
src/Menu.tsx            the site's only top chrome — a <details> in the top right:
                        home, work, the three languages, and the world's three
                        settings: which craft you steer, how rough its sea is,
                        and its sound
src/routes/home.tsx     /{lang} — the landing page: the ocean as CSS, the shore
                        over it (palms, cloud, sand — one SVG path and gradients),
                        one button, and the dolly that flies all of it past the
                        camera on the way into the world
src/routes/world.tsx    /{lang}/world — the world's address, and its flat fallback
src/routes/work.tsx     /{lang}/work — the flat index, never has a world behind it
src/routes/case-study.tsx  /{lang}/work/{slug} — a card with the world, the prose without
src/routes/not-found.tsx   /{lang}/404 — copied to build/client/404.html
src/content.ts          every MDX file, keyed by slug and locale
src/i18n/               locales.ts (routing + isWorldPath) + index.ts (strings) + a check
src/WorldGate.tsx       mounts the canvas once, decides where it shows, owns the
                        HUD and the sound state the menu toggles
src/MiniMap.tsx         the world's index since the panel went away — a top view
                        in the corner, a letter per project, the ship's arrow
src/Scene.tsx           the <Canvas> and everything in it
src/Scenery.tsx         sky, sun, ocean, clouds — all TSL, no assets
src/Post.tsx            the render pipeline — FXAA, and bloom off emissive only
src/Particles.tsx       the spray under the ship — GPU compute, WebGPU only
src/Sound.tsx           the ambient layer — Web Audio, synthesised, off by default
src/Islands.tsx         the ground under each landmark — lathed, no assets
src/Landmarks.tsx       the mine, the easel, the board — blockout in primitives +
                        TSL, and the detailed model where one exists (`MODEL`)
src/models/             the .glb files — geometry only, no materials, no UVs
tools/landmark.py       what every landmark script needs — axes, members, export
tools/mine.py           builds tools/mine.blend and src/models/mine.glb, headless
tools/easel.py          the same, for the easel
tools/board.py          the same, for the board
src/Debug.tsx           ?debug — radii, blockout boxes, waypoints
src/Ship.tsx            the character: the flight controller, and the two hulls
                        it drives — a hovering saucer and a boat on the water
src/useInput.ts         invariant 8 — the only place input is read, keys and touch
src/stick.ts            the thumb stick's arithmetic, and its check beside it
src/world.ts            landmark layout + proximity, read from the content
docs/STATUS.md          what is built and what is not — update it with the work
src/index.css           global styles — and `.world` / `.landing`, the two
                        classes on <html> that pin the chrome over the sea
src/content/projects/   {slug}.{lang}.mdx  (Phase 1, not yet written)
src/i18n/               UI strings per locale
docs/BUILD-PLAN.md      phases, gates, decisions, open questions, risks
deploy.sh               build + rsync to the server, then a routing smoke test
deploy/nginx.conf       the server block — root redirect, 404, caching
```

## Content

`src/content/projects/{slug}.{lang}.mdx`, and nothing lists them anywhere else —
`react-router.config.ts` reads the directory to build its prerender list.

English carries the structural frontmatter (`year`, `stack`, `site`, `repo`, and
the world's `landmark`, `order`, `pos`, `size`, `radius`, `waypoint`); `fr` and
`nl` carry only `title` and `summary` beside their prose. A URL is never written
down three times. A locale with no file for a slug falls back to English rather
than 404ing.

`pos` and `waypoint` are XZ only — the plateau height is one constant, `GROUND`
in `src/world.ts`. A `waypoint` must be inside its own `radius`, or a deep link
spawns the ship outside the landmark it just opened and the panel closes itself;
`world.ts` asserts it in dev.

Two more, asserted beside it, because the camera never yaws — it is always
`CAM_OFFSET` from the ship, +z and above — so where a landmark lands on the
screen is arithmetic on the waypoint: `pos[1] < waypoint[1]` puts it in front of
the ship rather than between the ship and the camera, and `pos[0] > waypoint[0]`
puts it in the right half of the frame, which is the half the reading panel does
not cover. Both survive `offshore`, so they hold for the boat too.

## Working together

**Ask first:** adding a dependency, adding a route, changing the render pipeline,
publishing an unreviewed translation, or starting a phase the plan gates.

**Just do it:** content edits, shader tweaks, styling, and any refactor that
makes the diff smaller.

## Current state

`docs/STATUS.md` is the source of truth. Update its boxes in the same commit as
the work.

Phases 0 to 4 are built, and Phase 6 with them: the models, the shaders, the
post-processing chain, the GPU particles, the ambient sound, and now touch. The sun was swung round to port in an
earlier pass, which is a change to the committed golden-hour look and is written
up in `docs/STATUS.md`.

Sound is synthesised in `src/Sound.tsx` — Web Audio, no files, no dependency,
+1.4 kB gz — and it is off until the visitor presses the one button in the HUD,
which is also the gesture the autoplay policy wants. Nothing is constructed
before that click.

The particles are WebGPU only and there is deliberately no WebGL2 version —
`docs/STATUS.md` has the argument. That makes them the first thing in the world
a visitor can miss, which is why `?debug` names the backend.

Touch is drag-to-fly, not tap-to-move: a drag on the world is a thumb stick
(`src/stick.ts`) read into `useInput`'s `move`, boost is the same push further,
rise is a second finger. Nothing is cut on a phone, and the whole phase cost
528 bytes gz. `docs/STATUS.md` has the layout it changed and the one camera
number it changed with it.

The visitor picks the craft in the menu, and the sea beside it — **calm** or
**agitated**, two states and not a dial. Both are remembered, and the sound is
not, because nothing in the platform refuses to give a returning visitor the
hull and the weather they chose, while it does refuse them sound before they
have clicked.

Calm is the chop the world shipped with, scaled up by `CHOP`. Agitated is that
same chop with three crossing trains of rollers under it — 96, 74 and 60 units
between crests, at spread headings, the tallest 2.6 against a 1.9 m mast, summed
so that no two crests line up twice. Three rather than one because one train is
a corrugated roof, every crest parallel to the last. They are the **one thing in
this world made of displaced geometry** —
Phase 3's "the surface stays geometrically flat" no longer holds for that term,
because a wave bigger than the ship that is only a painted normal has nothing to
ride and nothing to be thrown off. The rollers are damped to nothing over every
island's shallows (`shoal()` in `world.ts`), or a 2.8 m swell would put a 45 cm
plateau under water.

The boat's vertical is a buoyancy spring against the surface's own motion, and
gravity when the water drops away faster than the hull can follow — so a roller
taken at cruise is a ride and one taken at full sail is a jump, out of the
physics rather than out of a rule. Leaving the water and landing are the two
events on top of it: a kick on the way up (`POP`, which buys the height an
honest spring does not), and on the way down a compression of the bounce spring,
a ring of foam opening on the water and a burst out of the spray particles. One function still writes both the shader's uniform and
the CPU twin `swell()`, and the dev finite-difference assert beside it is what
keeps the water and the hull the same water. `docs/STATUS.md` has the numbers. The boat floats: its altitude is the
swell, it is pushed out of every island's shoreline instead of flying over it,
and arriving *alongside* an island is what opens the panel, because a hull can
never reach the circle the saucer triggers on.

What is open is Seb's: the first deploy and DNS/TLS (Phase 2's exit), Track B's
*is traversal interesting or a chore* judgement, reviewing the eight unreviewed
FR/NL UI strings (`worldControls`, `sound`, `worldControlsTouch`, the boat's two
control hints and the three craft labels), and judging
the lighting, the post-processing chain, the sound mix and now the stick's feel
on real hardware — swiftshader has no opinion about frame rate, a null audio sink
has none about levels, and neither has a thumb.
